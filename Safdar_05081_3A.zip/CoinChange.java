/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coinchange;
import java.util.*;

/**
 *
 * @author idea
 */
public class CoinChange {

    /**
     * @param args the command line arguments
     */
    
     //greedy algorithm implementation
    public static int greedyCoinChange(int denominations[],int value){
       
       int totalCoins=0;
       List<Integer> coinsSelected = new ArrayList<Integer>();
       
       int largestDenomination=-1;
        Arrays.sort(denominations);
        int arraySize = denominations.length;
          //check for the valid input      
        if(value<=0 || value < denominations[arraySize-1]){
           System.out.println("Invalid value cant't have denominations!");
           return 0;
        }
      // System.out.println("Coins selected");
        while(value!=0){
            //find the largest denominations that is <=value
            try{
            for(int i=0;i<arraySize;i++){
                    if(denominations[i]<=value){
                    largestDenomination = denominations[i];
                    }
            }
            //add selected coin
            int totalDen = value / largestDenomination;
            //adds total coins 
           for(int i = 0; i<totalDen;i++){
           coinsSelected.add(largestDenomination);
         //  System.out.println(largestDenomination+ "  ");
           
         }
           totalCoins+=totalDen;
           value = value % largestDenomination;
           
           
           }catch(Exception e){
               System.out.println();
           }
            
            
        }
       // System.out.println("\n total coins "+totalCoins);
        return  totalCoins;
    }
    
    public static int dpCoinChange(int n,int d[], int k){
        int C[] = new int[n+1];
        int coin=-1;
        
        C[0] = 0;
        
        int S[] = new int[n+1];
        
        
        S[0] = 0;
        //using dynamic approach to select dynamic programming
        for(int p=1;p<=n;p++){
            int min = Integer.MAX_VALUE;
            for(int i=0;i<k;i++){
                if(p>=d[i]){
                    if(C[p-d[i]]+1 < min){
                            min = C[p-d[i]]+1;
                            coin = i;
                        }
                }
                
            
            }
            C[p] = min;
            S[p] = coin;
        
        }
       
     return C[n];
        
    
    }
    
    public static void main(String[] args) {
        // TODO code application logic here
         //denominations given
         int coins[] = {1,5,10,20,25};
         int value = 35;//change for this value
        System.out.println("value: "+value);
        System.out.println("Greedy:");
        System.out.println("Total Coins selected are: "+ greedyCoinChange(coins,value));
        System.out.println(); 
        System.out.println("Dynamic:");
        System.out.println("Total Coins selected are: "+dpCoinChange(value,coins, coins.length));
        
        //Finding 10 numbers for which dynamic gives the optimal value
        int counter=0;
        int startValue = 40;
        int optimalGreedyTen[] = new int[10];
        while(counter<10){
            value = startValue;
            int greedyResult = greedyCoinChange(coins,value);
            int dpResult = dpCoinChange(value,coins, coins.length);
            
            if(dpResult<greedyResult){
                optimalGreedyTen[counter++]=value;
                //System.out.println(optimalGreedyTen[counter-1]);
            }
            
            startValue+=12;
        }
        System.out.println();
        System.out.println("10 optimal numbers for which dynamic prog is optimal:");
        for(int i=0;i<10;i++){
            System.out.println(optimalGreedyTen[i]);
        }
   }
    
}
