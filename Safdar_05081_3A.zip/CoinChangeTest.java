/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package coinchange;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author idea
 */
public class CoinChangeTest {
    
    public CoinChangeTest() {
    }
    
    /**
     * Test of greedyCoinChange method, of class CoinChange.
     */
    @Test
    public void testGreedyCoinChange() {
        System.out.println("greedyCoinChange");
        int[] denominations = {1,5,10,20,25};
        int value = 40;
        int expResult = 3;
        int result = CoinChange.greedyCoinChange(denominations, value);
        assertEquals(expResult, result);
        
    }

    /**
     * Test of dpCoinChange method, of class CoinChange.
     */
    @Test
    public void testDpCoinChange() {
        System.out.println("dpCoinChange");
        int n = 40;
        int[] d = {1,5,10,20,25};
        int k = 5;
        int expResult = 2;
        int result = CoinChange.dpCoinChange(n, d, k);
        assertEquals(expResult, result);
       
    }
/**
     * Test of dpCoinChange method, of class CoinChange.
     */
    @Test
    public void optimalityOfDp() {
        System.out.println("dpCoinChange");
        int n = 40;
        int[] d = {1,5,10,20,25};
        int k = 5;
        assertTrue(CoinChange.dpCoinChange(n, d, k)<CoinChange.greedyCoinChange(d, n));
        
        
       
    }
    
}
